package com.viewnext;

public class Patron_Type {

	public static void main(String[] args) {
		
		//Object dato = 1234;
		//Object dato = "Hola que tal?";
		//Object dato = 12348766899976L;
		Object dato = 12348.766899976;
		
		String formato = switch (dato) {
			case String texto -> texto;
			case Integer entero -> String.format("entero %d ", entero);
			case Double real -> String.format("double %.1f", real);
			case Long numLong -> String.format("long %d", numLong);
			
			default -> dato.toString();
		};
		
		System.out.println(formato);

	}

}
