package com.viewnext;

public class Patron_Guarded {

	public static void main(String[] args) {
		
		//Object dato = "pepito@gmail.com";
		//Object dato = "pepitogmail.com";
		//Object dato = "pepito@gmailcom";
		//Object dato = "pep";
		Object dato = 123;
		
		// Solo funciona a partir de Java 21
		String mensaje = switch (dato) {
			case String email -> {
				if (email.length() < 5)
					yield "Email no tiene suficientes caracteres";
				else if (! email.contains("@"))
					yield "Formato del email no es valido, falta @";
				else if (! email.contains("."))
					yield "Formato del email no es valido, falta .";
				else
					yield "Email valido";
			}
			default -> "Email no valido";
		};
		
		System.out.println(mensaje);

	}

}
