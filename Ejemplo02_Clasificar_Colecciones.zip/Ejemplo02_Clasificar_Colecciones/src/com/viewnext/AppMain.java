package com.viewnext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.viewnext.models.Alumno;
import com.viewnext.utils.ComparadorNota;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un arbol de alumnos
		Set<Alumno> alumnos = new TreeSet<Alumno>(new ComparadorNota());
		//Set<Alumno> alumnos = new TreeSet<Alumno>( (alum1, alum2) ->  (int) (alum1.getNota() - alum2.getNota()) );
		
		// Agregar 5 alumnos
		alumnos.add(new Alumno(1, "Juan", "Perez", 'H', 7.5, false));
		alumnos.add(new Alumno(2, "Maria", "Sanchez", 'M', 4.2, true));
		alumnos.add(new Alumno(3, "Pedro", "Gonzalez", 'H', 9.2, false));
		alumnos.add(new Alumno(4, "Luis", "Rodriguez", 'H', 8.3, false));
		alumnos.add(new Alumno(5, "Sara", "Garcia", 'M', 10, true));
		
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("----------------------");
		
		// Generar una lista a partir del arbol de alumnos
		List<Alumno> lista = new ArrayList<Alumno>(alumnos);
		
		// Clasificar la lista por apellido
		lista.sort( (a1,a2) -> a1.getApellido().compareTo(a2.getApellido())  );
		lista.forEach(System.out::println);
		System.out.println("----------------------");
		
		// Clasificar la lista por apellido descendente
		lista.sort( (a1,a2) -> a2.getApellido().compareTo(a1.getApellido())  );
		lista.forEach(System.out::println);
		System.out.println("----------------------");
		
		// Clasificar la lista por numAlumno
		lista.sort( (a1,a2) -> a1.getNumAlumno() - a2.getNumAlumno() );
		lista.forEach(System.out::println);
		System.out.println("----------------------");
		
		// Clasificar la lista por numAlumno descendente
		lista.sort( (a1,a2) -> a2.getNumAlumno() - a1.getNumAlumno() );
		lista.forEach(System.out::println);
		System.out.println("----------------------");
		
		// Clasificar la lista por nota ascendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota));
		lista.forEach(System.out::println);
		System.out.println("----------------------");
		
		// Clasificar la lista por nota descendente
		lista.sort(Comparator.comparingDouble(Alumno::getNota).reversed() );
		lista.forEach(System.out::println);
		System.out.println("----------------------");

	}

}
