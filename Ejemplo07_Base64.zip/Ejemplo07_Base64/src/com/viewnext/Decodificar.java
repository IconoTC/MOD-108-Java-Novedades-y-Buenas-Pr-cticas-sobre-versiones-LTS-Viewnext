package com.viewnext;

import java.util.Base64;

public class Decodificar {

	public static void main(String[] args) {
		
		String cadena = "RXN0byBlcyB1bmEgcHJ1ZWJhIHBhcmEgY29kaWZpY2FyIGNvbiBCYXNlIDY0";
		
		// Decodificar la cadena utilizando Base 64
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] arrayBytes = decoder.decode(cadena);
		String texto = new String(arrayBytes);
		
		System.out.println(texto);

	}

}
