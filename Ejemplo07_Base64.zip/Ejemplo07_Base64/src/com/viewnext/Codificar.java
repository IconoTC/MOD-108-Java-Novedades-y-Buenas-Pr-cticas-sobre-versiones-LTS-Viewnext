package com.viewnext;

import java.util.Base64;

public class Codificar {

	public static void main(String[] args) {
		
		String texto = "Esto es una prueba para codificar con Base 64";
		
		// Codificar el texto utilizando Base 64 
		Base64.Encoder encoder = Base64.getEncoder();
		String cadena = encoder.encodeToString(texto.getBytes());
		
		// Mostrar la cadena
		System.out.println(cadena); // RXN0byBlcyB1bmEgcHJ1ZWJhIHBhcmEgY29kaWZpY2FyIGNvbiBCYXNlIDY0

	}

}
