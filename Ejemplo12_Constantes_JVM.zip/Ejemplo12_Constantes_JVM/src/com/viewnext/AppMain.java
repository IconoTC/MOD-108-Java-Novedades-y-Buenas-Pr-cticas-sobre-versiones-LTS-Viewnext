package com.viewnext;

import java.lang.constant.ClassDesc;
import java.lang.constant.MethodTypeDesc;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear un descriptor para la clase java.util.ArrayList
		ClassDesc clase = ClassDesc.of("java.util", "ArrayList");
		
		System.out.println("Nombre: " + clase.displayName());
		System.out.println("Paquete: " + clase.packageName());
		System.out.println("Descriptor de clase: " + clase.descriptorString());
		
		// Crear un descriptor de metodo
		// No recibe parametros y retorna un String
		MethodTypeDesc metodoString = MethodTypeDesc.of(ClassDesc.of("java.lang.String"));
		System.out.println(metodoString);
		
		// Crear un descriptor de metodo
		// Recibe como parametro un entero y retorna un double
		MethodTypeDesc metodoDouble = MethodTypeDesc.of(ClassDesc.of("java.lang.Double"), ClassDesc.of("java.lang.Integer"));
		System.out.println(metodoDouble);

	}

}
