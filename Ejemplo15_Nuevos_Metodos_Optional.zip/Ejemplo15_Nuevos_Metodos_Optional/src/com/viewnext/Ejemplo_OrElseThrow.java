package com.viewnext;

import java.util.Optional;

public class Ejemplo_OrElseThrow {

	public static void main(String[] args) {
		
		//Optional<String> op = Optional.ofNullable("Buenas tardes");
		Optional<String> op = Optional.ofNullable(null);
		
		// Si el optional esta vacio lanzamos una excepcion
		// Si no lo esta, mostramos el valor
		//  java.util.NoSuchElementException: No value present
		//String valor = op.orElseThrow();
		//System.out.println(valor);
		
		// Lanzar la excepcion que queremos (elijo el tipo y el mensaje)
		// java.lang.RuntimeException: El optional esta vacio
		String valor = op.orElseThrow( () -> new RuntimeException("El optional esta vacio") );
		System.out.println(valor);

	}

}
