package com.viewnext;

import java.util.Arrays;
import java.util.Optional;

public class Ejemplo_Stream {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.of("     Esto es una prueba     ");
		
		// Primero quitar los espacios derecha e izquierda
		// Partir el texto por " "   split
		// Mostrar en la consola
		op.stream()
			.map(texto -> texto.strip())
			.map(texto -> Arrays.stream(texto.split(" ")))
			.forEach(x -> x.forEach(System.out::println));

	}

}
