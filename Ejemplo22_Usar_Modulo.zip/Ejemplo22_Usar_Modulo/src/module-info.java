module Ejemplo22_Usar_Modulo {
	
	// Para poder usar el modulo de otro proyecto
	// es necesario agregarlop como dependencia en el build path
	
	// requires nombre_modulo
	requires Ejemplo21_Crear_Modulo;
}