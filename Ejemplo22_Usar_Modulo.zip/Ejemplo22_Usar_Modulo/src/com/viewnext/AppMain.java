package com.viewnext;

import com.viewnext.models.Direccion;
import com.viewnext.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion direccion = new Direccion("Mayor", 5, "Madrid");
		Empleado empleado = new Empleado(1, "Juan", 54000, direccion);
		
		System.out.println(empleado);

	}

}
