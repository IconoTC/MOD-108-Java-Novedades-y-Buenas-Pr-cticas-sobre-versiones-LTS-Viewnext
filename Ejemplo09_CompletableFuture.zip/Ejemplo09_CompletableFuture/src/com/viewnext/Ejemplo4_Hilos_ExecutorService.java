package com.viewnext;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class Ejemplo4_Hilos_ExecutorService implements Callable<String>{
	
	int[] numeros;
	
	public Ejemplo4_Hilos_ExecutorService(int [] numeros) {
		this.numeros = numeros;
	}

	public static void main(String[] args) {
		
		// Arrancamos el hilo y lo hacemos a traves de un ExecutorService
		ExecutorService es = Executors.newFixedThreadPool(2);
		
		int [] numeros1 = {1,4,2,5,7};
		Future<String> hilo1 = es.submit(new Ejemplo4_Hilos_ExecutorService(numeros1));
		
		int [] numeros2 = {9,2,8,4};
		Future<String> hilo2 = es.submit(new Ejemplo4_Hilos_ExecutorService(numeros2));
		
		try {
			es.awaitTermination(5, TimeUnit.SECONDS);
			// Cuando se han ejecutado los 2 hilos, se para el ExecutorService
			es.shutdown();
			
			// Recogemos el resultado de cada hilo y lo mostramos
			String resultado1 = hilo1.get();
			System.out.println("Hilo 1 - " + resultado1);
			
			String resultado2 = hilo2.get();
			System.out.println("Hilo 2 - " + resultado2);
			
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		// Metemos un proceso en el hilo principal
		for (int i=1; i<=100; i++) {
			System.out.println("Hilo principal " + i);
		}

	}

	@Override
	public String call() throws Exception {
		// Esto es lo que ejecuta el hilo
		// Vamos a calcular la suma del array de numeros recibido
		int suma = 0;
		
		for (int num : numeros) {
			Thread.sleep(1000);
			suma += num;
		}
			
		return "Resultado: " + suma;
	}

}
