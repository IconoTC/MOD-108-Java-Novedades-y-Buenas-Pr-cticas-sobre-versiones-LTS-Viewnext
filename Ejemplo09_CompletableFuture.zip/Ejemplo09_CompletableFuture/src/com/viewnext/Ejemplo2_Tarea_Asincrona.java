package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo2_Tarea_Asincrona {

	public static void main(String[] args) throws InterruptedException {
		
		CompletableFuture<Void> future = CompletableFuture.runAsync( () -> {
			// Implementamos con un lambda el metodo run() de la interface Runnable
			// Todo el codigo que escribimos aqui, se ejecuta en un hilo aparte
			for (int i = 1; i <= 10; i++) {
				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Tarea asincrona " + i);
			}
		} );
		
		future.thenRun( () -> System.out.println("Tarea finalizada"));
		
		// El metodo main termina antes que la tarea asincrona
		// Paramos el hilo principal, le da tiempo a recibir los datos
		Thread.sleep(5000);

	}

}
