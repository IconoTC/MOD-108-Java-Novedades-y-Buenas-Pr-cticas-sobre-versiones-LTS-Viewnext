package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo1_Crear_Completable {

	public static void main(String[] args) {
		
		CompletableFuture<String> completableFuture = new CompletableFuture<String>();
		completableFuture.complete("Esto es una prueba");
		
		completableFuture.thenAccept(resultado -> System.out.println(resultado));
		completableFuture.thenAccept(System.out::println);

	}

}
