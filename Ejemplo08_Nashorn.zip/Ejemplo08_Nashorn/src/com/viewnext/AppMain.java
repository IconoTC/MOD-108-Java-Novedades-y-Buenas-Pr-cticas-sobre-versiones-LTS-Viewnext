package com.viewnext;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class AppMain {

	public static void main(String[] args) throws ScriptException {
		
		// IMPORTANTE!!! el proyecto debe estar con Jdk 8
		
		// Obtener una instancia del motor JS
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine nashorn = manager.getEngineByName("nashorn");
		
		// Ejecutar una instruccion JS
		nashorn.eval("print('Esto es una prueba');");
		
		// Ejecutar al archivo codigo.js
		nashorn.eval("load('codigo.js')");

	}

}
