package com.viewnext;

import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorSockets {

	public static void main(String[] args) {
		
		int puerto = 32915;
		
		try (ServerSocket servidor = new ServerSocket(puerto)){
			
			while(true) {
				try (Socket socket = servidor.accept();
						ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())){
					
					String mensaje = (String) ois.readObject();
					System.out.println("Mensaje recibido: " + mensaje);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
