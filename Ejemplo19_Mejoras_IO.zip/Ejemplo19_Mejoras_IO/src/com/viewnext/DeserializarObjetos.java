package com.viewnext;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.viewnext.models.Empleado;

public class DeserializarObjetos {

	public static void main(String[] args) {
		
		try (FileInputStream fichero = new FileInputStream("empleado.ser");
				ObjectInputStream inputStream = new ObjectInputStream(fichero)) {
			
			// Deserializar el objeto
			Empleado empleado = (Empleado) inputStream.readObject();
			System.out.println(empleado);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
