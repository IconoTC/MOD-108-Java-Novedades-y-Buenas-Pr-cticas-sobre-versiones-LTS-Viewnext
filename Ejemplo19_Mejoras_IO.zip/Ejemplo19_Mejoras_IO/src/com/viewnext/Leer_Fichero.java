package com.viewnext;

import java.io.BufferedReader;
import java.io.FileReader;

public class Leer_Fichero {

	public static void main(String[] args) {
		
		try (FileReader fichero = new FileReader("datos.txt");
				BufferedReader br = new BufferedReader(fichero)){
			
			br.lines()
				.map(linea -> linea.toUpperCase())
				.forEach(System.out::println);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
