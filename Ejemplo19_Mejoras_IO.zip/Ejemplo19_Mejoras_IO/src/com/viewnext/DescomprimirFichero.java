package com.viewnext;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;

public class DescomprimirFichero {

	public static void main(String[] args) {
		
		try (FileInputStream fichero = new FileInputStream("comprimido.zip");
				GZIPInputStream gStream = new GZIPInputStream(fichero);
				BufferedReader bReader = new BufferedReader(new InputStreamReader(gStream))){
			
			// Leer el fichero
			bReader.lines()
				.forEach(System.out::println);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
