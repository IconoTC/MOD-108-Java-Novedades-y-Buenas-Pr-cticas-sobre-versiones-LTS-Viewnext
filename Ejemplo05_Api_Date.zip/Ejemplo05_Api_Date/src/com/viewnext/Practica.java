package com.viewnext;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class Practica {

	public static void main(String[] args) {
		
		// Lincoln nace el 12 de Febrero de 1809
		// Fallece el 15 de Abril de 1855
		LocalDate nacimiento = LocalDate.of(1809, Month.FEBRUARY, 12);
		LocalDate fallecimiento = LocalDate.of(1855, Month.APRIL, 15);
		
		// Cuantos años tenia cuando fallecio?
		System.out.println("Lincoln murio con " + nacimiento.until(fallecimiento, ChronoUnit.YEARS) + " años");
		System.out.println("Lincoln murio con " + Period.between(nacimiento, fallecimiento).getYears() + " años");
		
		// Cuantos dias vivio?
		System.out.println("Lincoln vivio " + nacimiento.until(fallecimiento, ChronoUnit.DAYS) + " dias");
		System.out.println("Lincoln vivio " + Period.between(nacimiento, fallecimiento).toTotalMonths() * 30 + " dias");
		System.out.println("Lincoln vivio " + Period.between(nacimiento, fallecimiento) + " dias");
		
		// Si el año de su nacimiento era bisiesto?
		System.out.println("Era bisiesto cuando nacio? " + nacimiento.isLeapYear());
		
		// Cuantas decadas han transcurrido desde su fallecimiento?
		LocalDate hoy = LocalDate.now();
		System.out.println("Decadas desde su fallecimiento " + nacimiento.until(hoy, ChronoUnit.DECADES) );
		
		// Que dia de la semana nacio?
		System.out.println("Dia de la semana que nacio: " + nacimiento.getDayOfWeek());
		
		// Que dia de la semana fue su 30 cumpleaños?
		System.out.println("Dia de su 30 cumple: " + nacimiento.plusYears(30).getDayOfWeek());
		System.out.println("Dia de su 30 cumple: " + nacimiento.withYear(30).getDayOfWeek());

	}

}
