package com.viewnext;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class EjemplosLocalDate {

	public static void main(String[] args) {
		
		// Fecha actual
		LocalDate hoy = LocalDate.now();
		System.out.println(hoy);
		
		// Fecha de mi cumpleaños
		LocalDate miCumple = LocalDate.of(2026, Month.JULY, 1);
		
		// Ya ha sido tu compleaños?
		System.out.println("Tu cumple todavia no ha sido " + miCumple.isAfter(hoy));
		System.out.println("Tu cumple ya ha sido " + miCumple.isBefore(hoy));
		
		// Este año es bisiesto?
		System.out.println("Es bisiesto? " + hoy.isLeapYear());
		
		// En que dia de la semana estamos
		System.out.println("Estamos en " + hoy.getDayOfWeek());
		
		// En que mes estamos
		System.out.println("Estamos en el mes " + hoy.getMonth());
		System.out.println("Estamos en el mes " + hoy.getMonthValue());
		
		// Modificar fechas
		System.out.println(hoy.plusDays(1));
		System.out.println(hoy.plusMonths(1));
		System.out.println(hoy.plusWeeks(1));
		System.out.println(hoy.plusYears(1));
		
		System.out.println(hoy.minusDays(1));
		System.out.println(hoy.minusMonths(1));
		System.out.println(hoy.minusWeeks(1));
		System.out.println(hoy.minusYears(1));
		
		// Fecha del proximo domingo
		System.out.println("Proximo domingo: " + hoy.with(TemporalAdjusters.next(DayOfWeek.SUNDAY)));

	}

}
