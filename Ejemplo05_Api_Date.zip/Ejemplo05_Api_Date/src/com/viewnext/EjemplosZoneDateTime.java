package com.viewnext;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

public class EjemplosZoneDateTime {

	public static void main(String[] args) {
		
		// Mostrar las zonas horarias
		System.out.println(ZoneId.getAvailableZoneIds());
		
		// Crear una zona horaria
		ZoneId USEast = ZoneId.of("America/New_York");
		
		// Hora actual de Madrid
		LocalTime ahora = LocalTime.now();
		System.out.println("Ahora en Madrid: " + ahora);
		
		// Hora actual en Nueva York
		System.out.println(ZonedDateTime.now(USEast).truncatedTo(ChronoUnit.MINUTES));
		
		// Crear fecha y hora en España
		LocalDateTime spain = LocalDateTime.of(2026, Month.AUGUST, 10, 21, 30);
		ZonedDateTime horaSpain = ZonedDateTime.of(spain, ZoneId.of("Europe/Madrid"));
		System.out.println("Hora en España: " + horaSpain);
		
		// Convertir esa fecha en horario New York
		ZonedDateTime horaNewYork = ZonedDateTime.of(spain, USEast);
		System.out.println("Hora en Nueva York: " + horaNewYork);
		

	}

}
