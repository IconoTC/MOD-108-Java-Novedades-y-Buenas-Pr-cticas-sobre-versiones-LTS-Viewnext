module Ejemplo21_Crear_Modulo{
	
	// exports paquete
	exports com.viewnext.models;
}