package com.viewnext;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class AppMain {

	public static void main(String[] args) {
		
		// Los archivos .properties llevan el codigo de idiomas ISO 639-1
		
		// Crear los locales (que idiomas vamos a utilizar)
		//Locale espanyol = new Locale("es", "ES");
		Locale colombiano = new Locale("es", "CL");
		Locale ingles = new Locale("en");
		
		// Otra forma de crear los locales
		Locale espanyol = new Locale.Builder()
				.setLanguage("es")
				.setRegion("ES")
				.build();
		
		// Cargar os archivos de mensajes para cada locale
		ResourceBundle esESBundle = ResourceBundle.getBundle("mensajes", espanyol);
		ResourceBundle esCLBundle = ResourceBundle.getBundle("mensajes", colombiano);
		ResourceBundle enBundle = ResourceBundle.getBundle("mensajes", ingles);
		
		// Mostrar el saludo en los 3 idiomas
		System.out.println(esESBundle.getString("saludo"));
		System.out.println(esCLBundle.getString("saludo"));
		System.out.println(enBundle.getString("saludo"));
		
		// Felicitar a alguien pasando el nombre como parametro
		System.out.println(MessageFormat.format(esESBundle.getString("felicitar"), "Pepito"));
		System.out.println(MessageFormat.format(esCLBundle.getString("felicitar"), "Pepito"));
		System.out.println(MessageFormat.format(enBundle.getString("felicitar"), "Pepito"));
	}

}
