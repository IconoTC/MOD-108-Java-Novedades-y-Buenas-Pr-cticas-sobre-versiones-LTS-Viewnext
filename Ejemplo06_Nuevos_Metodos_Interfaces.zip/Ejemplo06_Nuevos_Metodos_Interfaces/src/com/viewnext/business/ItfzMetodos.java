package com.viewnext.business;

public interface ItfzMetodos {
	
	// Novedad en Java 8:
	//	- Métodos estaticos
	//	- Métodos default
	
	public static void estatico() {
		System.out.println("Metodo estatico");
		// Desde un metodo estatico no puedo acceder a los metodo private
		// porque nos on estaticos
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
		// Desde los metodos default si podemos llamar a los metodos private
	}
	
	// Novedad en Java 9:
	//	- Metodos privados
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) +
				" Minusculas: " + minusculas(texto);
	}

}
