package com.viewnext;

import com.viewnext.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Invocar al metodo estatico de la interface
		ItfzMetodos.estatico();
		
		// Invocar al metodo default de la interface
		ItfzMetodos obj = new ItfzMetodos() {
		};
		obj.defecto();
		
		System.out.println(obj.procesarTexto("Hola, que tal?"));

	}

}
