package com.viewnext;

import com.viewnext.models.Avion;
import com.viewnext.models.ObjetoVolador;
import com.viewnext.models.Pajaro;

public class AppMain {

	public static void main(String[] args) {
		
		ObjetoVolador avion = new Avion();
		avion.despegar();
		avion.aterrizar();
		avion.volar();
		
		Pajaro pajaro = new Pajaro();
		pajaro.ponerHuevos();
		pajaro.hacerNido();

	}

}
