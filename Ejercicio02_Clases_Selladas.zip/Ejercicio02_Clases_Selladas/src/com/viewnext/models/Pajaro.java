package com.viewnext.models;

public non-sealed class Pajaro extends Ave{

	@Override
	public void despegar() {
		System.out.println("El pajaro despega");
	}

	@Override
	public void aterrizar() {
		System.out.println("El pajaro aterriza");
	}

	@Override
	public void volar() {
		System.out.println("El pajaro vuela");
	}
	
	public void hacerNido() {
		System.out.println("El pajaro hace el nido");
	}
	
	public void ponerHuevos() {
		System.out.println("El pajaro pone huevos");
	}
}
