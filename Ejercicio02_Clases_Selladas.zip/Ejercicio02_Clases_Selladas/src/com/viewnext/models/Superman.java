package com.viewnext.models;

public final class Superman implements ObjetoVolador{

	@Override
	public void despegar() {
		System.out.println("Superman despega");
	}

	@Override
	public void aterrizar() {
		System.out.println("Superman aterriza");
	}

	@Override
	public void volar() {
		System.out.println("Superman vuela");
	}
	
	public void saltarEdificio() {
		System.out.println("Superman salta edificios");
	}
	
	public void detenerBala() {
		System.out.println("Superman detiene balas");
	}

}
