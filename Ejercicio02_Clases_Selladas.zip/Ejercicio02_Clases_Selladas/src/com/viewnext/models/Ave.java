package com.viewnext.models;

public sealed class Ave implements ObjetoVolador permits Pajaro{

	@Override
	public void despegar() {
		System.out.println("El ave despega");
	}

	@Override
	public void aterrizar() {
		System.out.println("El ave aterriza");
	}

	@Override
	public void volar() {
		System.out.println("El ave vuela");
	}
	
	public void hacerNido() {
		System.out.println("El ave hace el nido");
	}
	
	public void ponerHuevos() {
		System.out.println("El ave pone huevos");
	}

}
