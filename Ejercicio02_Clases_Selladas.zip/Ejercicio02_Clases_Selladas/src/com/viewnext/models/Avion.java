package com.viewnext.models;

public non-sealed class Avion implements ObjetoVolador{

	@Override
	public void despegar() {
		System.out.println("El avion despega");
	}

	@Override
	public void aterrizar() {
		System.out.println("El avion aterriza");
	}

	@Override
	public void volar() {
		System.out.println("El avion vuela");
	}

}
