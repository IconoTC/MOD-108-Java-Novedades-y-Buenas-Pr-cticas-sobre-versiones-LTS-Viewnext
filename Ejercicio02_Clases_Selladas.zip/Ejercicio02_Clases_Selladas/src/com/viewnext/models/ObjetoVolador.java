package com.viewnext.models;

public sealed interface ObjetoVolador permits Avion, Ave, Superman{
	
	void despegar();
	
	void aterrizar();
	
	void volar();

}
