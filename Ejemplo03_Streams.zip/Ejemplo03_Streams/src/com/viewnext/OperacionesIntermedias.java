package com.viewnext;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.viewnext.models.Provincia;

public class OperacionesIntermedias {

	public static void main(String[] args) {
		List<Provincia> lista = Arrays.asList(
				new Provincia("Madrid", 87, 67_886_543, 28, "Español", "Madrid", 90.67),
				new Provincia("Valencia", 45, 7876876, 46 , "Valenciano", "Valencia", 91.3),
				new Provincia("Coruña", 39, 54545, 9, "Gallego", "Coruña", 78.23),
				new Provincia("Toledo", 26, 3677556, 38, "Español", "Toledo", 35.17),
				new Provincia("Ourense", 29, 788866, 27, "Gallego", "Ourense", 28.68),
				new Provincia("Cuenca", 15, 986442, 16, "Español", "Cuenca", 34.12),
				new Provincia("Barcelona", 74, 556779, 8, "Catalan", "Barcelona", 97.25),
				new Provincia("Zamora", 28, 987656, 42, "Español", "Zamora", 56.34),
				new Provincia("Guipuzcoa", 35, 432223, 20, "Euskera", "San Sebastian", 48.23),
				new Provincia("Vizcaya", 48, 567654, 6, "Euskera", "Bilbao", 54.89)	
		);
		
		// Mostrar los nombres de las provincias con densidad de poblacion superior a 50
		lista.stream()
			.filter(prov -> prov.getDensidadPoblacion() > 50)
			.map(p -> p.getNombre())
			//.forEach(p -> System.out.println(p));
			.forEach(System.out::println);
		System.out.println("-----------------------------");
		
		// Mostrar los distintos dialectos (.distinct) ordenados de forma descendente
		lista.stream()
			.map(p -> p.getDialecto())
			.distinct()
			.sorted(Comparator.reverseOrder())
			.forEach(System.out::println);
		System.out.println("-----------------------------");
		
		// Mostrar las provincias que tienen menos de 40 localidades ordenadas por el codigo postal
		lista.stream()
			.filter(prov -> prov.getNumLocalidades() < 40)
			.sorted(Comparator.comparingInt(Provincia::getCodigoPostal))
			.forEach(System.out::println);
		System.out.println("-----------------------------");
		
		// Mostrar las provincias con dialecto Español ordenadas por el numero de localidades
		lista.stream()
			.filter(prov -> "Español".equals(prov.getDialecto()))
			.sorted( (p1,p2) -> p1.getNumLocalidades() - p2.getNumLocalidades() )
			.forEach(System.out::println);
		System.out.println("-----------------------------");
		
		// Mostrar las 3 primeras provincias
		lista.stream()
			.limit(3)
			.forEach(System.out::println);
		System.out.println("-----------------------------");
		
		// Mostrar las 3 ultimas, saltandose las 7 primeras
		lista.stream()
			.skip(7)
			.forEach(System.out::println);
		System.out.println("-----------------------------");
		
		// peek -> realiza una operacion final y devuelve el elemento al stream
		// Util para ir mostrando los resultados intermedios
		lista.stream()
			.peek(p -> System.out.println("Procesando " + p + "--------"))
			.filter(p -> p.getDensidadPoblacion() > 70)
			.peek(p -> System.out.println("Resultado " + p + "--------"))
			.map(p -> p.getNombre())
			.forEach(System.out::println);
		System.out.println("-----------------------------");

	}

}
