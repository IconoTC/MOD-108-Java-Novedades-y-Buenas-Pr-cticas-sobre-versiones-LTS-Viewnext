package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		// repeat
		System.out.println("-".repeat(30));
		System.out.println("_".repeat(30));
		System.out.println("*".repeat(30));
		System.out.println("ja".repeat(30));
		
		// strip elimina solo espacios en blanco
		String nombre = "     Buenas tardes     ";
		System.out.println(nombre + ".");
		
		// Quitar los espacios de izquierda y derecha
		System.out.println(nombre.strip() + ".");
		
		// Quitar los espacios por la izquierda
		System.out.println(nombre.stripLeading() + ".");
		
		// Quitar los espacios por la derecha
		System.out.println(nombre.stripTrailing() + ".");
		
		// lines
		String texto = "Esto\nes una prueba\ndel metodo lines";
		System.out.println(texto);
		texto.lines()   // genera un stream con las 3 lineas del texto
			.map(linea -> linea.toUpperCase())
			.forEach(System.out::println);
	}

}




