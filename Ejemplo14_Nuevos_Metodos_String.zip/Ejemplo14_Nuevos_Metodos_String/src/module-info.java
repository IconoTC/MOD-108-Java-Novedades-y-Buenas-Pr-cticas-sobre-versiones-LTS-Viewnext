module Ejemplo14_Nuevos_Metodos_String {
}