package com.viewnext.business;

// Una interface funcional tiene un solo metodo abstracto

@FunctionalInterface
public interface ItfzFuncional {
	
	String infoPersonas(String nombre, int edad);

}
