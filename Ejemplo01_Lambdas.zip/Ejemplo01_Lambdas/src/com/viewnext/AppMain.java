package com.viewnext;

import com.viewnext.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis: parametros -> cuerpo del metodo
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros es obligatorio usar los parentesis
		// No es obligatorio poner el tipo de los parametros
		// Si el cuerpo de la funcion es una sola linea tampoco es obligatorio las {}
		ItfzFuncional lambda1 = (n,e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda1.infoPersonas("Pepito", 25));
		
		// Si pongo el tipo de dato a los parametros, todos o ninguno
		// Si solo tengo un parametro y le pongo el tipo es obligatio los parentesis
		ItfzFuncional lambda2 = (String n,int e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda2.infoPersonas("Pepito", 25));
		
		// Si pongo return es obligatorio las llaves en el cuerpo del metodo
		// Si el cuerpo del metodo va entre llaves es obligatorio poner el return
		ItfzFuncional lambda3 = (n,e) -> {
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 25));
		
		// Si el cuerpo del metodo son varias lineas es obligatorio las llaves
		ItfzFuncional lambda4 = (n,e) -> {
			e++;
			n = n.toUpperCase();
			return "nombre: " + n + " edad: " + e;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 25));
		
		// Los lambdas soportan la inferencia de tipos
		// var en todos los parametros o ninguno
		ItfzFuncional lambda5 = (var n, var e) -> "nombre: " + n + " edad: " + e;
		System.out.println(lambda5.infoPersonas("Pepito", 25));

	}

}
