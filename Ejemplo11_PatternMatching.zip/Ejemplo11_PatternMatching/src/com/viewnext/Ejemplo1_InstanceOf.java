package com.viewnext;

public class Ejemplo1_InstanceOf {

	public static void main(String[] args) {
	
		//Object dato = 67;
		Object dato = "Buenas tardes";
		
		// Antes de Java 11
		if (dato instanceof Integer) {
			// Hacemos un casting
			Integer numero = (Integer) dato;
			System.out.println(++numero);
		}
		
		// Novedad en Java 11
		if (dato instanceof Integer numero) {
			System.out.println(++numero);
		} else if (dato instanceof String texto) {
			System.out.println(texto.toUpperCase());
		}

	}

}
