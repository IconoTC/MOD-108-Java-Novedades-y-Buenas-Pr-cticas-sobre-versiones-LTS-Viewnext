package com.viewnext;

import java.util.Scanner;

public class Ejemplo2_Switch_Case {

	public static void main(String[] args) {
		
		// Solicitar el numero del mes al usuario
		// utilizando switch-case decir cuantos dias tiene
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el numero del mes (1-12): ");
		int mes = sc.nextInt();
		
		// Antes de Java 11
//		int dias = 0;
//		switch (mes) {
//			case 1:
//			case 3:
//			case 5:
//			case 7:
//			case 8:
//			case 10:
//			case 12:
//				dias = 31;
//				break;
//			case 2:
//				dias = 28;
//				break;
//			case 4:
//			case 6:
//			case 9:
//			case 11:
//				dias = 30;
//				break;
//			default:
//				System.out.println("Mes no valido");
//				break;
//		}
		
		// Novedades en Java 11
		int dias = switch (mes) {
			case 1,3,5,7,8,10,12 -> 31;
			case 2 -> 28;
			case 4,6,9,11 -> 30;
			default -> throw new RuntimeException("Mes no valido");
		};
		
		System.out.println("El mes " + mes + " tiene " + dias + " dias");
	}

}
