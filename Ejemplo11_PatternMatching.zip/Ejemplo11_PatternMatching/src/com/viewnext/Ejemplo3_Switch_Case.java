package com.viewnext;

import java.util.Scanner;

public class Ejemplo3_Switch_Case {

	public static void main(String[] args) {
		
		// Solicitar el numero del mes al usuario
		// utilizando switch-case decir cuantos dias tiene
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el numero del mes (1-12): ");
		int mes = sc.nextInt();
		
		
		// Novedades en Java 11
		int dias = switch (mes) {
			case 1,3,5,7,8,10,12: 
				yield 31;
			case 2:
				yield 28;
			case 4,6,9,11:
				yield 30;
			default:
				throw new RuntimeException("Mes no valido");
		};
		
		System.out.println("El mes " + mes + " tiene " + dias + " dias");
	}

}
