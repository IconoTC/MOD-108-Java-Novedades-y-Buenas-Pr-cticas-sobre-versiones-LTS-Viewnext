package com.viewnext.models;

public final class Elipse extends Circulo{

	// .....
}
