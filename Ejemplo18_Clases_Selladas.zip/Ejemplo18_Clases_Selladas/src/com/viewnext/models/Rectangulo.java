package com.viewnext.models;


// Quitamos el sellado a la clase Rectangulo
public non-sealed class Rectangulo extends Figura{
	
	private double base;
	private double altura;
	
	public Rectangulo() {
		// TODO Auto-generated constructor stub
	}

	public Rectangulo(double base, double altura) {
		super();
		this.base = base;
		this.altura = altura;
	}
	
	@Override
	public double calcularArea() {
		return base * altura;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public String toString() {
		return "Rectangulo [base=" + base + ", altura=" + altura + "]";
	}

}
