package com.viewnext.models;

// Una clase sellada controla que subclase tiene permiso para heredar de ella
// De momento, solo Circulo puede heredar de Figura
// Ahora Rectangulo tambien puede heredar de Figura
public abstract sealed class Figura permits Circulo, Rectangulo{
	
	public abstract double calcularArea();

}
